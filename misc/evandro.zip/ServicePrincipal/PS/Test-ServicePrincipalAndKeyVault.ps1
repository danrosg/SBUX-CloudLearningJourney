﻿<#
.SYNOPSIS
    Test a new Service Principal integration with Azure Key Vault
.DESCRIPTION
    Test a new Service Principal integration with Azure Key Vault by creating, reading and deleting a secret and key.
    -IsServicePrincipalReadOnly:$false => is intended for deployment Service Principal
    -IsServicePrincipalReadOnly:$true => is intended for runtime Service Principal, make sure the secrets and keys already exist before running it on this mode
.NOTES
    File Name  : Test-ServicePrincipalAndKeyVault.ps1
    Author     : epereira@starbucks.com
    Company    : Starbucks Corporation (Copyright (c) 2017 Starbucks Corporation. All rights reserved.)
.EXAMPLE
    .\Test-ServicePrincipalAndKeyVault.ps1 -SubscriptionId "fc513365-0821-451c-a5b3-acf82568d8ce" -TenantId "ee69be27-d938-4eb5-8711-c5e69ca43718" -ServicePrincipalApplicationId "76a75f32-e7e2-42b6-b50b-e971df9d9f0a" -Password "Starbucks1234" -keyVaultName "s00197npkvt00001" -SecretName "Secret1" -SecretValuePlainText "123" -KeyName "HsmKey1" -IsServicePrincipalReadOnly:$false
#>


Param (
    [Parameter(Mandatory=$true)]
    [String]
    $SubscriptionId,

    [Parameter(Mandatory=$true)]
    [String]
    $TenantId,

    [Parameter(Mandatory=$true)]
    [String]
    $ServicePrincipalApplicationId,

    # This is the password used for login with the Service Principal
    [Parameter(Mandatory=$true)]
    [String]
    $Password,

    [Parameter(Mandatory=$true)]
    [String]
    $KeyVaultName,

    [Parameter(Mandatory=$true)]
    [String]
    $SecretName,

    [Parameter(Mandatory=$true)]
    [String]
    $SecretValuePlainText,

    [Parameter(Mandatory=$true)]
    [String]
    $KeyName,

    [Parameter(Mandatory=$false)]
    [String]
    $IsServicePrincipalReadOnly = $false
)


# Modules --------------------------------------------------------------->
Import-Module AzureRM.Resources


# Helper Functions ------------------------------------------------------>
function WriteTitle($message)
{
    Write-Host "***** $($message) *****" -ForegroundColor Cyan
}

function WriteText($message)
{
    Write-Host $message -ForegroundColor Yellow
}

function WriteSuccess()
{
    Write-Host "[Done]" -ForegroundColor Green
    Write-Host
    Write-Host
}

function WriteError($message)
{
    Write-Host $message -ForegroundColor Red
}


# Attention ------------------------------------------------------------->
if ($IsServicePrincipalReadOnly -eq $true)
{
    WriteTitle("ATTENTION")
    WriteText("Only READ-ONLY operations will be executed, no secret or key will be created during this test.")
    WriteText("Make sure secret '$($SecretName)' and key '$($KeyName)' exist before running.")
    WriteText("Press <ENTER> to proceed...")
    Pause
    WriteText
    WriteText
}


# Login to Azure -------------------------------------------------------->
WriteTitle("AUTHENTICATION")
WriteText("Logging in to Azure...")

$securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
$creds = New-Object System.Management.Automation.PSCredential ($ServicePrincipalApplicationId, $securePassword)
Add-AzureRmAccount -ServicePrincipal -Credential $creds -TenantId $TenantId -ErrorAction Stop
WriteSuccess


# Test secrets ---------------------------------------------------------->
WriteTitle("SECRETS TEST")
if ($IsServicePrincipalReadOnly -eq $false)
{
    WriteText("Creating secret '$($SecretName)'...")
    $SecretValueSecureString = ConvertTo-SecureString -String $SecretValuePlainText -AsPlainText -Force
    Set-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $SecretName -SecretValue $SecretValueSecureString
    WriteSuccess
}

WriteText("Reading secret '$($SecretName)'...")
Get-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $SecretName
WriteSuccess

if ($IsServicePrincipalReadOnly -eq $false)
{
    WriteText("Deleting secret '$($SecretName)'...")
    Remove-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $SecretName -Force -Confirm:$false
    WriteSuccess
}


# Test keys ------------------------------------------------------------->
if ($IsServicePrincipalReadOnly -eq $false)
{
    WriteTitle("KEYS TEST")
    WriteText("Creating key '$($KeyName)'...")
    Add-AzureKeyVaultKey -VaultName $KeyVaultName -Name $KeyName -Destination "HSM"
    WriteSuccess
}

WriteText("Reading key '$($KeyName)'...")
Get-AzureKeyVaultKey -VaultName $KeyVaultName -Name $KeyName
WriteSuccess

if ($IsServicePrincipalReadOnly -eq $false)
{
    WriteText("Deleting key '$($KeyName)'...")
    Remove-AzureKeyVaultKey -VaultName $KeyVaultName -Name $KeyName -Force -Confirm:$false
    WriteSuccess
}


return 0