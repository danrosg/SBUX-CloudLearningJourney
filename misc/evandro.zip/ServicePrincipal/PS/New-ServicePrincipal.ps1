﻿<#
.SYNOPSIS
    Provisions a new Service Principal
.DESCRIPTION
    Provisions a new Service Principal (along with password)
.NOTES
    File Name  : New-ServicePrincipal.ps1
    Author     : epereira@starbucks.com
    Company    : Starbucks Corporation (Copyright (c) 2017 Starbucks Corporation. All rights reserved.)
.EXAMPLE
    .\New-ServicePrincipal.ps1 -SubscriptionId "fc513365-0821-451c-a5b3-acf82568d8ce" -ServicePrincipalName "s00197ServicePrincipal2" -Password "Starbucks1234"
#>


Param (
    [Parameter(Mandatory=$true)]
    [String]
    $SubscriptionId,

    [Parameter(Mandatory=$true)]
    [String]
    $ServicePrincipalName,

    # This is the password used for login with the Service Principal
    [Parameter(Mandatory=$true)]
    [String]
    $Password
)


# Modules --------------------------------------------------------------->
Import-Module AzureRM.Resources


# Helper Functions ------------------------------------------------------>
function WriteTitle($message)
{
    Write-Host "***** $($message) *****" -ForegroundColor Cyan
}

function WriteText($message)
{
    Write-Host $message -ForegroundColor Yellow
}

function WriteSuccess()
{
    Write-Host "[Done]" -ForegroundColor Green
    Write-Host
    Write-Host
}

function WriteError($message)
{
    Write-Host $message -ForegroundColor Red
}


# Login to Azure -------------------------------------------------------->
WriteTitle("AUTHENTICATION")
WriteText("Logging in to Azure...")
Login-AzureRmAccount -ErrorAction Stop
WriteSuccess


# Set Context to Subscription Id ---------------------------------------->
WriteTitle("SUBSCRIPTION CONTEXT")
WriteText("Setting subscription context...")
Set-AzureRmContext -SubscriptionId $SubscriptionId -ErrorAction Stop
WriteSuccess


# Create Service Principal ---------------------------------------------->
WriteTitle("SERVICE PRINCIPAL")

# Create AD application
WriteText("Provisioning AD Application...")
$Application = New-AzureRmADApplication -DisplayName $ServicePrincipalName -HomePage ("http://" + $ServicePrincipalName) -IdentifierUris ("http://" + $ServicePrincipalName) -Password $Password
WriteSuccess

# Create Service Principal for the AD Application ----------------------->
WriteText("Provisioning Service Principal for AD Application...")
$ServicePrincipal = New-AzureRMADServicePrincipal -ApplicationId $Application.ApplicationId
Get-AzureRmADServicePrincipal -ObjectId $ServicePrincipal.Id
WriteSuccess

return 0