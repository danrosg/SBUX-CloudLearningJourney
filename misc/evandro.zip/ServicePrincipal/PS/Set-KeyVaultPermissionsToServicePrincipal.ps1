﻿<#
.SYNOPSIS
    Assign Azure Key Vault permissions to a Service Principal
.DESCRIPTION
    Assign Azure Key Vault permissions to a Service Principal, based on its type:
    a) Deploy  : this Service Principal will have all permissions to certificates, keys and secrets and it is intended to be used during deployment only;
    a) Runtime : this Service Principal will have read-only permissions to certificates, keys and secrets and it is intended to be used in runtime by applications;

    CAUTION: Make sure to refresh the entire page after running this script because the Azure portal UI sometimes does not refresh correctly.
.NOTES
    File Name  : Set-KeyVaultPermissionsToServicePrincipal.ps1
    Author     : epereira@starbucks.com
    Company    : Starbucks Corporation (Copyright (c) 2017 Starbucks Corporation. All rights reserved.)
.EXAMPLE
    .\Set-KeyVaultPermissionsToServicePrincipal.ps1 -SubscriptionId "fc513365-0821-451c-a5b3-acf82568d8ce" -ServicePrincipalObjectId "0d36d574-015e-4c9c-866d-118219964681" -ServicePrincipalType Deploy -keyVaultName "s00197npkvt00001" -keyVaultResourceGroupName "s00197nprgpkvt00001"
    .\Set-KeyVaultPermissionsToServicePrincipal.ps1 -SubscriptionId "fc513365-0821-451c-a5b3-acf82568d8ce" -ServicePrincipalObjectId "0d36d574-015e-4c9c-866d-118219964681" -ServicePrincipalType Runtime -keyVaultName "s00197npkvt00001" -keyVaultResourceGroupName "s00197nprgpkvt00001"
#>

Param (
    [Parameter(Mandatory=$true)]
    [String]
    $SubscriptionId,

    [Parameter(Mandatory=$true)]
    [String]
    $ServicePrincipalObjectId,
 
    [ValidateSet(“Deploy”,”Runtime”)]
    [Parameter(Mandatory=$false)]
    [String]
    $ServicePrincipalType,
 
    [Parameter(Mandatory=$false)]
    [String]
    $keyVaultName,
 
    [Parameter(Mandatory=$false)]
    [String]
    $keyVaultResourceGroupName
)
 
# Modules --------------------------------------------------------------->
Import-Module AzureRM.Resources
 
 
# Helper Functions ------------------------------------------------------>
function WriteTitle($message)
{
    Write-Host "***** $($message) *****" -ForegroundColor Cyan
}
 
function WriteText($message)
{
    Write-Host $message -ForegroundColor Yellow
}
 
function WriteSuccess()
{
    Write-Host "[Done]" -ForegroundColor Green
    Write-Host
    Write-Host
}
 
function WriteError($message)
{
    Write-Host $message -ForegroundColor Red
}
 
 
# Login to Azure -------------------------------------------------------->
WriteTitle("AUTHENTICATION")
WriteText("Logging in to Azure...")
Login-AzureRmAccount -ErrorAction Stop
WriteSuccess


# Set Context to Subscription Id ---------------------------------------->
WriteTitle("SUBSCRIPTION CONTEXT")
WriteText("Setting subscription context...")
Set-AzureRmContext  -SubscriptionId $SubscriptionId -ErrorAction Stop
WriteSuccess


# Assign Key Vault Permissions to Service Principal --------------------->
if(![string]::IsNullOrWhiteSpace($keyVaultName) -and ![string]::IsNullOrWhiteSpace($keyVaultResourceGroupName))
{
    WriteTitle("KEY VAULT PERMISSIONS")
    WriteText("Assigning Key Vault permissions to Service Principal...")
 
    if ($ServicePrincipalType -eq "Runtime")
    {
        WriteText("Setting READ-ONLY permissions...")
        Set-AzureRmKeyVaultAccessPolicy -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName -ObjectId $ServicePrincipalObjectId -PermissionsToCertificates list,get -PermissionsToKeys list,get,decrypt -PermissionsToSecrets list,get
    }
    else
    {
        WriteText("Setting ALL permissions...")
        Set-AzureRmKeyVaultAccessPolicy -VaultName $keyVaultName -ResourceGroupName $keyVaultResourceGroupName -ObjectId $ServicePrincipalObjectId -PermissionsToCertificates all -PermissionsToKeys all -PermissionsToSecrets all
    }
 
    WriteSuccess

    return 0
}

return -1