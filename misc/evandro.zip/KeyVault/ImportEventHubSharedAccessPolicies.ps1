﻿<#
.SYNOPSIS
    Import Event Hub shared access policies into Azure Key Vault and disabled unused versions
.DESCRIPTION
    Import Event Hub shared access policies into Azure Key Vault 
.NOTES
    File Name  : ImportEventHubSharedAccessPolicies.ps1
    Author     : epereira@starbucks.com
    Company    : Starbucks Corporation (Copyright (c) 2017 Starbucks Corporation. All rights reserved.)
.EXAMPLE
    .\ImportEventHubSharedAccessPolicies.ps1 -SubscriptionId "fc513365-0821-451c-a5b3-acf82568d8ce" -TenantId "ee69be27-d938-4eb5-8711-c5e69ca43718" -ServicePrincipalApplicationId "<Service Principal ApplicationId (Guid)>" -Password "<Service Principal Password or Key (String)>" -keyVaultName "s00197npkvt00001" -ResourceGroupName "s00197rgp0crdfuldev0" -NamespaceName "s00197evh0crdfuldev0" -EventHubName "svcgateway"
#>


Param (
    [Parameter(Mandatory=$true)]
    [String]
    $SubscriptionId,

    [Parameter(Mandatory=$true)]
    [String]
    $TenantId,

    [Parameter(Mandatory=$true)]
    [String]
    $ServicePrincipalApplicationId,

    # This is the password used for login with the Service Principal
    [Parameter(Mandatory=$true)]
    [String]
    $Password,

    [Parameter(Mandatory=$true)]
    [String]
    $KeyVaultName,

    [Parameter(Mandatory=$true)]
    [String]
    $ResourceGroupName,

    [Parameter(Mandatory=$true)]
    [String]
    $NamespaceName,

    [Parameter(Mandatory=$true)]
    [String]
    $EventHubName
)


# Modules --------------------------------------------------------------->
Import-Module AzureRM.Resources
Import-Module AzureRM.EventHub


# Helper Functions ------------------------------------------------------>
function WriteTitle($message)
{
    Write-Host "***** $($message) *****" -ForegroundColor Cyan
}

function WriteText($message)
{
    Write-Host $message -ForegroundColor Yellow
}

function WriteSuccess()
{
    Write-Host "[Done]" -ForegroundColor Green
    Write-Host
    Write-Host
}

function WriteError($message)
{
    Write-Host $message -ForegroundColor Red
}


# Login to Azure -------------------------------------------------------->
WriteTitle("AUTHENTICATION")
WriteText("Logging in to Azure...")

$securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
$creds = New-Object System.Management.Automation.PSCredential ($ServicePrincipalApplicationId, $securePassword)
Add-AzureRmAccount -ServicePrincipal -Credential $creds -TenantId $TenantId -ErrorAction Stop
WriteSuccess


# Set Context to Subscription Id ---------------------------------------->
WriteTitle("SUBSCRIPTION SELECTION")
WriteText("Setting subscription context...")
Select-AzureRmSubscription -SubscriptionId $SubscriptionId
WriteSuccess


# Secrets --------------------------------------------------------------->
WriteTitle("SECRETS")

# List access keys
WriteText("Reading shared access policies...") 
$policies = Get-AzureRmEventHubAuthorizationRule -ResourceGroupName $ResourceGroupName -NamespaceName $NamespaceName -EventHubName $EventHubName -ErrorAction Stop
WriteSuccess

foreach ($policy in $policies)
{
    WriteText("Reading policy '$($policy.Name)' access keys...")

    # Retrieve access keys
    $keys = Get-AzureRmEventHubKey -ResourceGroupName $ResourceGroupName -NamespaceName $NamespaceName -EventHubName $EventHubName -AuthorizationRuleName $policy.Name -ErrorAction Stop
    WriteSuccess

    # Prepare arrays with secret names and values
    $secretNames = @("$($NamespaceName)-$($EventHubName)-$($policy.Name)-PrimaryConnectionString", "$($NamespaceName)-$($EventHubName)-$($policy.Name)-SecondaryConnectionString")
    $secretValues = @($keys.PrimaryConnectionString, $keys.SecondaryConnectionString)

    for ($i=0; $i -lt $secretNames.length; $i++)
    {
        # Create secret
        WriteText("Creating secret '$($secretNames[$i])'...")
        $SecretValueSecureString = ConvertTo-SecureString -String $secretValues[$i] -AsPlainText -Force
        Set-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $secretNames[$i] -SecretValue $SecretValueSecureString -ErrorAction Stop

        # Disable Unused Versions (if any)
        WriteText("Disabling secret '$($secretNames[$i])' old versions, only first 2 will be left enabled...")

        $secretVersions = Get-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $secretNames[$i] -IncludeVersions -ErrorAction Stop
        $secretVersions

        for ($j=0; $j -lt $secretVersions.length; $j++)
        {
            if ($j -gt 1)
            {
                if ($secretVersions[$j].Enabled -eq $true)
                {
                    # Disable secret version if it is enabled
                    WriteText("Disabling secret '$($secretVersions[$j].Name)' version '$($secretVersions[$j].Version)'...")
                    Set-AzureKeyVaultSecretAttribute -VaultName $KeyVaultName -Name $secretVersions[$j].Name -Version $secretVersions[$j].Version -Enable $false -ErrorAction Stop
                }
                else
                {
                    WriteText("Secret '$($secretVersions[$j].Name)' version '$($secretVersions[$j].Version)' is already disabled...")
                }

                WriteSuccess
            }
        }
    }
}