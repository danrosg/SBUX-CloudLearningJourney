﻿<#
.SYNOPSIS
    Imports a certificate into Azure Key Vault
.DESCRIPTION
    Imports a certificate into Azure Key Vault
.NOTES
    File Name  : ImportCertificate.ps1
    Author     : epereira@starbucks.com
    Company    : Starbucks Corporation (Copyright (c) 2017 Starbucks Corporation. All rights reserved.)
.EXAMPLE
    .\ImportCertificate.ps1 -SubscriptionId "fc513365-0821-451c-a5b3-acf82568d8ce" -TenantId "ee69be27-d938-4eb5-8711-c5e69ca43718" -ServicePrincipalApplicationId "<Service Principal ApplicationId (Guid)>" -Password "<Service Principal Password or Key (String)>" -keyVaultName "s00197npkvt00001" -CertificateName "s00197crdfuldev0clientcert" -CertificatePassword "Starbucks1234" -CertificateFilePath "c:\temp\s00197crdfuldev0clientcert.pfx" -Email "DL-DPAPIPlatform-InfrastructureTeam@starbucks.com" -Tags @{"subscription" = "NP"; "environment" = "Dev"; "location" = "USA"; "region" = "East US"; "domain" = "Card1"; "appname" = "Card Fulfillment"; "appdescription" = "Card Fulfillment"; "apptype" = "API"; "tier" = "Data"; "fgid" ="00197"; "objectname" = "s00197crddev0clientcert"}
#>


Param (
    [Parameter(Mandatory=$true)]
    [String]
    $SubscriptionId,

    [Parameter(Mandatory=$true)]
    [String]
    $TenantId,

    [Parameter(Mandatory=$true)]
    [String]
    $ServicePrincipalApplicationId,

    # This is the password used for login with the Service Principal
    [Parameter(Mandatory=$true)]
    [String]
    $Password,

    [Parameter(Mandatory=$true)]
    [String]
    $KeyVaultName,

    [Parameter(Mandatory=$true)]
    [String]
    $CertificateName,

    [Parameter(Mandatory=$true)]
    [String]
    $CertificatePassword,

    [Parameter(Mandatory=$true)]
    [String]
    $CertificateFilePath,

    [Parameter(Mandatory=$true)]
    [String]
    $Email,

    [Parameter(Mandatory=$true)]
    $Tags
)


# Modules --------------------------------------------------------------->
Import-Module AzureRM.Resources


# Helper Functions ------------------------------------------------------>
. ..\Util\PS\Util.ps1


# Login to Azure -------------------------------------------------------->
WriteTitle("AUTHENTICATION")
WriteText("Logging in to Azure...")

$securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
$creds = New-Object System.Management.Automation.PSCredential ($ServicePrincipalApplicationId, $securePassword)
Add-AzureRmAccount -ServicePrincipal -Credential $creds -TenantId $TenantId -ErrorAction Stop
WriteSuccess


# Set Context to Subscription Id ---------------------------------------->
WriteTitle("SUBSCRIPTION SELECTION")
WriteText("Setting subscription context...")
Select-AzureRmSubscription -SubscriptionId $SubscriptionId -ErrorAction Stop
WriteSuccess


# Import Certificate ---------------------------------------------------->
WriteTitle("IMPORT CERTIFICATE")
WriteText("Importing certificate '$($CertificateName)' from '($CertificateFilePath)'...")

$secureCertificatePassword = ConvertTo-SecureString $CertificatePassword -AsPlainText -Force
Import-AzureKeyVaultCertificate -VaultName $KeyVaultName -Name $CertificateName -FilePath $CertificateFilePath -Password $secureCertificatePassword -Tag $Tags -ErrorAction Stop

WriteSuccess


# Add Contact for Certificate Notifications ----------------------------->
WriteTitle("ADD CONTACT FOR CERTIFICATE NOTIFICATIONS")

WriteText("Getting current Azure Key Vault contacts...")
$contacts = Get-AzureKeyVaultCertificateContact -VaultName $KeyVaultName
$contacts
WriteSuccess

WriteText("Checking if contact '($Email)' already exists in Azure Key Vault current Azure Key Vault contacts...")
$contactExists = $false;

for ($i=0; $i -lt $contacts.Count; $i++)
{
    if ($contacts[$i].Email -eq $Email)
    {
        $contactExists = $true;
        break;
    }
}

WriteSuccess

if ($contactExists -eq $false)
{
    WriteText("Registering contact in Azure Key Vault...")
    
    # The following cmdlet accepts one e-mail at a time
    Add-AzureKeyVaultCertificateContact -VaultName $KeyVaultName -EmailAddress $Email -PassThru
}
else
{
    WriteText("Contact is ALREADY registered in the Azure Key Vault, no work was done...")
}

WriteSuccess


# Disable Unused Versions (if any) -------------------------------------->
WriteTitle("DISABLE CERTIFICATE OLD UNUSED VERSIONS")
WriteText("Find below all certificate '$($CertificateName)' versions, only latest 2 version will be left enabled...")

$certificateVersions = Get-AzureKeyVaultCertificate -VaultName $KeyVaultName -Name $CertificateName -IncludeVersions -ErrorAction Stop

# This is to output all certificate versions in the console
$certificateVersions

WriteSuccess

WriteText

for ($i=0; $i -lt $certificateVersions.length; $i++)
{
    if ($i -gt 1)
    {
        if ($certificateVersions[$i].Enabled -eq $true)
        {
            # Disable secret version if it is enabled
            WriteText("Disabling certificate '$($certificateVersions[$i].Name)' version '$($certificateVersions[$i].Version)'...")
            Set-AzureKeyVaultCertificateAttribute -VaultName $KeyVaultName -Name $certificateVersions[$i].Name -Version $certificateVersions[$i].Version -Enable $false -ErrorAction Stop
        }
        else
        {
            WriteText("Certificate '$($certificateVersions[$i].Name)' version '$($certificateVersions[$i].Version)' is already disabled...")
        }

        WriteSuccess
    }
}