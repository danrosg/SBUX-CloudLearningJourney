﻿<#
.SYNOPSIS
    Imports generic secret value into Azure Key Vault
.DESCRIPTION
    Imports generic secret value into Azure Key Vault
.NOTES
    File Name  : ImportGenericSecret.ps1
    Author     : epereira@starbucks.com
    Company    : Starbucks Corporation (Copyright (c) 2017 Starbucks Corporation. All rights reserved.)
.EXAMPLE
    .\ImportGenericSecret.ps1 -SubscriptionId "fc513365-0821-451c-a5b3-acf82568d8ce" -TenantId "ee69be27-d938-4eb5-8711-c5e69ca43718" -ServicePrincipalApplicationId "<Service Principal ApplicationId (Guid)>" -Password "<Service Principal Password or Key (String)>" -keyVaultName "s00197npkvt00001" -SecretName "s00197rgp0crdfuldev0" -SecretValue "s00197evh0crdfuldev0"
#>


Param (
    [Parameter(Mandatory=$true)]
    [String]
    $SubscriptionId,

    [Parameter(Mandatory=$true)]
    [String]
    $TenantId,

    [Parameter(Mandatory=$true)]
    [String]
    $ServicePrincipalApplicationId,

    # This is the password used for login with the Service Principal
    [Parameter(Mandatory=$true)]
    [String]
    $Password,

    [Parameter(Mandatory=$true)]
    [String]
    $KeyVaultName,

    [Parameter(Mandatory=$true)]
    [String]
    $SecretName,

    [Parameter(Mandatory=$true)]
    [String]
    $SecretValue
)


# Modules --------------------------------------------------------------->
Import-Module AzureRM.Resources


# Helper Functions ------------------------------------------------------>
function WriteTitle($message)
{
    Write-Host "***** $($message) *****" -ForegroundColor Cyan
}

function WriteText($message)
{
    Write-Host $message -ForegroundColor Yellow
}

function WriteSuccess()
{
    Write-Host "[Done]" -ForegroundColor Green
    Write-Host
    Write-Host
}

function WriteError($message)
{
    Write-Host $message -ForegroundColor Red
}


# Login to Azure -------------------------------------------------------->
WriteTitle("AUTHENTICATION")
WriteText("Logging in to Azure...")

$securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
$creds = New-Object System.Management.Automation.PSCredential ($ServicePrincipalApplicationId, $securePassword)
Add-AzureRmAccount -ServicePrincipal -Credential $creds -TenantId $TenantId -ErrorAction Stop
WriteSuccess


# Set Context to Subscription Id ---------------------------------------->
WriteTitle("SUBSCRIPTION SELECTION")
WriteText("Setting subscription context...")
Select-AzureRmSubscription -SubscriptionId $SubscriptionId
WriteSuccess


# Secrets --------------------------------------------------------------->
WriteTitle("SECRETS")
WriteText("Creating secret '$($SecretName)'...")
$SecretValueSecureString = ConvertTo-SecureString -String $SecretValue -AsPlainText -Force
Set-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $SecretName -SecretValue $SecretValueSecureString -ErrorAction Stop
WriteSuccess


# Disable Unused Versions (if any) -------------------------------------->
WriteText("Disabling secret '$($SecretName)' old versions, only first 2 will be left enabled...")

$secretVersions = Get-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $SecretName -IncludeVersions -ErrorAction Stop
$secretVersions

for ($i=0; $i -lt $secretVersions.length; $i++)
{
    if ($i -gt 1)
    {
        if ($secretVersions[$i].Enabled -eq $true)
        {
            # Disable secret version if it is enabled
            WriteText("Disabling secret '$($secretVersions[$i].Name)' version '$($secretVersions[$i].Version)'...")
            Set-AzureKeyVaultSecretAttribute -VaultName $KeyVaultName -Name $secretVersions[$i].Name -Version $secretVersions[$i].Version -Enable $false -ErrorAction Stop
        }
        else
        {
            WriteText("Secret '$($secretVersions[$i].Name)' version '$($secretVersions[$i].Version)' is already disabled...")
        }

        WriteSuccess
    }
}