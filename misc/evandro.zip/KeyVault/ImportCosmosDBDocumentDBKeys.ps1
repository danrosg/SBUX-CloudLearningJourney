﻿<#
.SYNOPSIS
    Retrieve CosmosDB/DocumentDB access keys and import them to Azure Key Vault
.DESCRIPTION
    Retrieve CosmosDB/DocumentDB access keys and import them to Azure Key Vault
.NOTES
    File Name  : ImportCosmosDBDocumentDBKeys.ps1
    Author     : epereira@starbucks.com
    Company    : Starbucks Corporation (Copyright (c) 2017 Starbucks Corporation. All rights reserved.)
.EXAMPLE
    .\ImportCosmosDBDocumentDBKeys.ps1 -SubscriptionId "fc513365-0821-451c-a5b3-acf82568d8ce" -TenantId "ee69be27-d938-4eb5-8711-c5e69ca43718" -ServicePrincipalApplicationId "<Service Principal ApplicationId (Guid)>" -Password "<Service Principal Password or Key (String)>" -keyVaultName "s00197npkvt00001" -ResourceGroupName "s00197rgp0crdfuldev0" -ResourceType "Microsoft.DocumentDb/databaseAccounts" -ResourceName "s00197ddb0crdfuldev0"
#>


Param (
    [Parameter(Mandatory=$true)]
    [String]
    $SubscriptionId,

    [Parameter(Mandatory=$true)]
    [String]
    $TenantId,

    [Parameter(Mandatory=$true)]
    [String]
    $ServicePrincipalApplicationId,

    # This is the password used for login with the Service Principal
    [Parameter(Mandatory=$true)]
    [String]
    $Password,

    [Parameter(Mandatory=$true)]
    [String]
    $KeyVaultName,

    [Parameter(Mandatory=$true)]
    [String]
    $ResourceGroupName,

    [Parameter(Mandatory=$true)]
    [String]
    $ResourceType,

    [Parameter(Mandatory=$true)]
    [String]
    $ResourceName
)


# Modules --------------------------------------------------------------->
Import-Module AzureRM.Resources


# Helper Functions ------------------------------------------------------>
function WriteTitle($message)
{
    Write-Host "***** $($message) *****" -ForegroundColor Cyan
}

function WriteText($message)
{
    Write-Host $message -ForegroundColor Yellow
}

function WriteSuccess()
{
    Write-Host "[Done]" -ForegroundColor Green
    Write-Host
    Write-Host
}

function WriteError($message)
{
    Write-Host $message -ForegroundColor Red
}


# Login to Azure -------------------------------------------------------->
WriteTitle("AUTHENTICATION")
WriteText("Logging in to Azure...")

$securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
$creds = New-Object System.Management.Automation.PSCredential ($ServicePrincipalApplicationId, $securePassword)
Add-AzureRmAccount -ServicePrincipal -Credential $creds -TenantId $TenantId -ErrorAction Stop
WriteSuccess


# Set Context to Subscription Id ---------------------------------------->
WriteTitle("SUBSCRIPTION SELECTION")
WriteText("Setting subscription context...")
Select-AzureRmSubscription -SubscriptionId $SubscriptionId
WriteSuccess


# Secrets --------------------------------------------------------------->
WriteTitle("SECRETS")


# ATTENTION:
# There is an open issue at https://github.com/Azure/azure-powershell/issues/3650 about listConnectionStrings action returning an empty result
# This prevents automation to have a secret for the entire connection string
# For now, we will upload only the access keys
WriteText("Reading access keys...") 
$keys = Invoke-AzureRmResourceAction -Action listKeys -ResourceType $ResourceType -ApiVersion "2016-03-31" -ResourceGroupName $ResourceGroupName -Name $ResourceName -Force
$keys
WriteSuccess

# Prepare arrays with secret names and values
$secretNames = @("$($ResourceName)-primaryMasterKey", "$($ResourceName)-secondaryMasterKey", "$($ResourceName)-primaryReadonlyMasterKey", "$($ResourceName)-secondaryReadonlyMasterKey")
$secretValues = @($keys.primaryMasterKey, $keys.secondaryMasterKey, $keys.secondaryReadonlyMasterKey, $keys.primaryReadonlyMasterKey)

# Upload
for ($i=0; $i -lt $secretNames.length; $i++)
{
    # Create secret
    WriteText("Creating secret '$($secretNames[$i])'...")
    $SecretValueSecureString = ConvertTo-SecureString -String $secretValues[$i] -AsPlainText -Force
    Set-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $secretNames[$i] -SecretValue $SecretValueSecureString -ErrorAction Stop
    WriteSuccess

    # Disable Unused Versions (if any)
    WriteText("Disabling secret '$($secretNames[$i])' old versions, only first 2 will be left enabled...")

    $secretVersions = Get-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $secretNames[$i] -IncludeVersions -ErrorAction Stop
    $secretVersions

    for ($j=0; $j -lt $secretVersions.length; $j++)
    {
        if ($j -gt 1)
        {
            if ($secretVersions[$j].Enabled -eq $true)
            {
                # Disable secret version if it is enabled
                WriteText("Disabling secret '$($secretVersions[$j].Name)' version '$($secretVersions[$j].Version)'...")
                Set-AzureKeyVaultSecretAttribute -VaultName $KeyVaultName -Name $secretVersions[$j].Name -Version $secretVersions[$j].Version -Enable $false -ErrorAction Stop
            }
            else
            {
                WriteText("Secret '$($secretVersions[$j].Name)' version '$($secretVersions[$j].Version)' is already disabled...")
            }

            WriteSuccess
        }
    }
}

return 0