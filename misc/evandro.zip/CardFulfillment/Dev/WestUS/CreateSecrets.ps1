﻿# West US


# Helper Functions ------------------------------------------------------>
function WriteHeader($message)
{
    Write-Host 
    Write-Host "******************** $($message) at $(Get-Date -format 'u') ********************" -ForegroundColor Magenta
    Write-Host 
}


# Common Variables ------------------------------------------------------>

$subscriptionId = "fc513365-0821-451c-a5b3-acf82568d8ce"
$tenantId = "ee69be27-d938-4eb5-8711-c5e69ca43718"
$servicePrincipalApplicationId = "<Service Principal ApplicationId (Guid)>"
$password = "<Service Principal Password or Key (String)>"
$keyVaultName = "s00197npkvt10001"
$resourceGroupName = "s00197rgp1crdfuldev0"


# Event Hub Variables --------------------------------------------------->
WriteHeader("[START] EVENT HUB")

$EventHubNamespace = "s00197evh1crdfuldev0"
$EventHubName = "svcgateway"

..\..\..\KeyVault\ImportEventHubSharedAccessPolicies.ps1 -SubscriptionId $subscriptionId -TenantId $tenantId -ServicePrincipalApplicationId $servicePrincipalApplicationId -Password $password -keyVaultName $keyVaultName -ResourceGroupName $resourceGroupName -NamespaceName $EventHubNamespace -EventHubName $EventHubName

WriteHeader("[END] EVENT HUB")


# Servbice Bus Variables ------------------------------------------------>
WriteHeader("[START] SERVICE BUS")

..\..\..\KeyVault\ImportGenericSecret.ps1 -SubscriptionId $subscriptionId -TenantId $tenantId -ServicePrincipalApplicationId $servicePrincipalApplicationId -Password $password -keyVaultName $keyVaultName -SecretName "s00197svb1crdfuldev0-RootManageSharedAccessKey-PrimaryConnectionString" -SecretValue "<Enter Connection String Here>"
..\..\..\KeyVault\ImportGenericSecret.ps1 -SubscriptionId $subscriptionId -TenantId $tenantId -ServicePrincipalApplicationId $servicePrincipalApplicationId -Password $password -keyVaultName $keyVaultName -SecretName "s00197svb1crdfuldev0-RootManageSharedAccessKey-SecondaryConnectionString" -SecretValue "<Enter Connection String Here>"

WriteHeader("[END] SERVICE BUS")


return 0