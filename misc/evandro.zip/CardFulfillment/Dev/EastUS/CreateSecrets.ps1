﻿# East US


# Helper Functions ------------------------------------------------------>
. ..\..\..\Util\PS\Util.ps1


# Common Variables ------------------------------------------------------>
$subscriptionId = "fc513365-0821-451c-a5b3-acf82568d8ce"
$tenantId = "ee69be27-d938-4eb5-8711-c5e69ca43718"
$servicePrincipalApplicationId = "<Service Principal ApplicationId (Guid)>"
$password = "<Service Principal Password or Key (String)>"
$keyVaultName = "s00197npkvt00001"
$resourceGroupName = "s00197rgp0crdfuldev0"


# CosmosDB/DocumentDB Variables ----------------------------------------->
WriteHeader("[START] COSMOSDB/DOCUMENTDB")

$DocumentDbResourceType = "Microsoft.DocumentDb/databaseAccounts"
$DocumentDbAccountName = "s00197ddb0crdfuldev0"

..\..\..\KeyVault\ImportCosmosDBDocumentDBKeys.ps1 -SubscriptionId $subscriptionId -TenantId $tenantId -ServicePrincipalApplicationId $servicePrincipalApplicationId -Password $password -keyVaultName $keyVaultName -ResourceGroupName $resourceGroupName -ResourceType $DocumentDbResourceType -ResourceName $DocumentDbAccountName

# Adding the following automation to compensate for issue https://github.com/Azure/azure-powershell/issues/3650
..\..\..\KeyVault\ImportGenericSecret.ps1 -SubscriptionId $subscriptionId -TenantId $tenantId -ServicePrincipalApplicationId $servicePrincipalApplicationId -Password $password -keyVaultName $keyVaultName -SecretName "s00197ddb0crdfuldev0-PrimaryConnectionString" -SecretValue "<Enter Connection String Here>"
..\..\..\KeyVault\ImportGenericSecret.ps1 -SubscriptionId $subscriptionId -TenantId $tenantId -ServicePrincipalApplicationId $servicePrincipalApplicationId -Password $password -keyVaultName $keyVaultName -SecretName "s00197ddb0crdfuldev0-SecondaryConnectionString" -SecretValue "<Enter Connection String Here>"

WriteHeader("[END] COSMOSDB/DOCUMENTDB")


# Event Hub Variables --------------------------------------------------->
WriteHeader("[START] EVENT HUB")

$EventHubNamespace = "s00197evh0crdfuldev0"
$EventHubName = "svcgateway"

..\..\..\KeyVault\ImportEventHubSharedAccessPolicies.ps1 -SubscriptionId $subscriptionId -TenantId $tenantId -ServicePrincipalApplicationId $servicePrincipalApplicationId -Password $password -keyVaultName $keyVaultName -ResourceGroupName $resourceGroupName -NamespaceName $EventHubNamespace -EventHubName $EventHubName

WriteHeader("[END] EVENT HUB")


# Servbice Bus Variables ------------------------------------------------>
WriteHeader("[START] SERVICE BUS")

$ServiceBusNamespace = "s00197svb0crdfuldev0"

..\..\..\KeyVault\ImportServiceBusSharedAccessPolicies.ps1 -SubscriptionId $subscriptionId -TenantId $tenantId -ServicePrincipalApplicationId $servicePrincipalApplicationId -Password $password -keyVaultName $keyVaultName -ResourceGroupName $resourceGroupName -NamespaceName $ServiceBusNamespace

WriteHeader("[END] SERVICE BUS")


# CosmosDB/Table Variables ---------------------------------------------->
WriteHeader("[START] COSMOSDB/TABLE")

..\..\..\KeyVault\ImportGenericSecret.ps1 -SubscriptionId $subscriptionId -TenantId $tenantId -ServicePrincipalApplicationId $servicePrincipalApplicationId -Password $password -keyVaultName $keyVaultName -SecretName "s00197tbl0crdfuldev0-ReadWriteConnectionString" -SecretValue "<Enter Connection String Here>"
..\..\..\KeyVault\ImportGenericSecret.ps1 -SubscriptionId $subscriptionId -TenantId $tenantId -ServicePrincipalApplicationId $servicePrincipalApplicationId -Password $password -keyVaultName $keyVaultName -SecretName "s00197tbl0crdfuldev0-ReadOnlyConnectionString" -SecretValue "<Enter Connection String Here>"

WriteHeader("[END] COSMOSDB/TABLE")


return 0